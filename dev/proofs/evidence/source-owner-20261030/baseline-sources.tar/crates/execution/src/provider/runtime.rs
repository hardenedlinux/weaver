//! Guarded provider invocation; no retry, redirect, reconnect or automatic route fallback.
use super::sse;
use reqwest::{
    blocking::{Client, Response},
    redirect::Policy,
};
use std::{
    collections::{BTreeMap, BTreeSet},
    sync::{Arc, OnceLock},
    time::Duration,
};
use weaver_contracts::{Error, ProviderEvent, ProviderPlan, ProviderRoute, Result};
use weaver_ledger::Ledger;

/// Process-owned provider credentials and a bounded, non-retrying HTTPS client.
#[derive(Clone)]
pub struct ProviderTransport {
    inner: Arc<Settings>,
}
struct Settings {
    credentials: BTreeMap<String, String>,
    root: Option<reqwest::Certificate>,
    client: OnceLock<std::result::Result<Client, String>>,
}
impl ProviderTransport {
    pub fn new(credentials: BTreeMap<String, String>, root_pem: Option<&[u8]>) -> Result<Self> {
        for (target, secret) in &credentials {
            weaver_contracts::identifier(target)?;
            if secret.is_empty()
                || secret.len() > 4096
                || !secret.bytes().all(|b| b.is_ascii_graphic())
            {
                return Err(Error::Invalid("provider credential"));
            }
        }
        let root = root_pem
            .map(reqwest::Certificate::from_pem)
            .transpose()
            .map_err(|_| Error::Invalid("provider trust root"))?;
        Ok(Self {
            inner: Arc::new(Settings {
                credentials,
                root,
                client: OnceLock::new(),
            }),
        })
    }
    fn eligible(&self) -> BTreeSet<String> {
        self.inner.credentials.keys().cloned().collect()
    }
    fn open(&self, plan: &ProviderPlan, route: &ProviderRoute) -> Result<Response> {
        crate::HttpsTransport::validate_endpoint(&route.endpoint)?;
        let client = self
            .inner
            .client
            .get_or_init(|| {
                let mut builder = Client::builder()
                    .https_only(true)
                    .http1_only()
                    .no_proxy()
                    .redirect(Policy::none())
                    .retry(reqwest::retry::never())
                    .connect_timeout(Duration::from_secs(3))
                    .timeout(Duration::from_secs(10))
                    .pool_max_idle_per_host(0);
                if let Some(root) = &self.inner.root {
                    builder = builder.tls_certs_only([root.clone()]);
                }
                builder
                    .build()
                    .map_err(|_| "provider client unavailable".into())
            })
            .as_ref()
            .map_err(|_| Error::Invalid("provider client"))?;
        let secret = self
            .inner
            .credentials
            .get(&route.target)
            .ok_or(Error::Denied)?;
        let response = client
            .post(&route.endpoint)
            .bearer_auth(secret)
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .body(plan.body.clone())
            .send()
            .map_err(|_| Error::Conflict("provider outcome unknown"))?;
        if response.status() != 200
            || response
                .headers()
                .get("content-type")
                .and_then(|v| v.to_str().ok())
                .is_none_or(|v| v.split(';').next().map(str::trim) != Some("text/event-stream"))
        {
            return Err(Error::Conflict(
                "provider did not return an admitted SSE stream",
            ));
        }
        Ok(response)
    }
}
/// Starts at most one source-bound request. The callback receives bounded batches only
/// under a fresh Cedar release guard; its error leaves the release and budget unknown.
pub trait ProviderOutput {
    type Slot;
    fn stopped(&self) -> bool;
    fn reserve(&mut self) -> Result<Self::Slot>;
    fn emit(
        &mut self,
        slot: Self::Slot,
        route: &ProviderRoute,
        model: &str,
        events: &[ProviderEvent],
    ) -> Result<()>;
}
/// Named execution inputs keep route authority distinct from output queue custody.
pub struct ProviderExecution<'a> {
    pub plan: &'a ProviderPlan,
    pub transport: &'a ProviderTransport,
    pub format: &'a str,
    pub batch_rows: usize,
}
/// Validate the response profile, then run the consumed provider pipeline once.
pub fn execute_provider<O: ProviderOutput>(
    ledger: &mut Ledger,
    request: ProviderExecution<'_>,
    output: &mut O,
) -> Result<()> {
    execute_stream(
        ledger,
        request.plan,
        request.transport,
        request.format,
        request.batch_rows,
        output,
    )
}
fn execute_stream<O: ProviderOutput>(
    ledger: &mut Ledger,
    plan: &ProviderPlan,
    transport: &ProviderTransport,
    format: &str,
    batch_rows: usize,
    output: &mut O,
) -> Result<()> {
    if !(1..=32).contains(&batch_rows)
        || !matches!(format, "protobuf" | "arrow")
        || output.stopped()
    {
        return Err(Error::Invalid("provider response profile or cancellation"));
    }
    for route in &plan.routes {
        crate::HttpsTransport::validate_endpoint(&route.endpoint)?;
    }
    ledger.enqueue_provider(plan)?;
    if output.stopped() {
        return Err(Error::Conflict("cancelled before provider consumption"));
    }
    let permit = ledger.consume_provider(&plan.family, &plan.node, &transport.eligible())?;
    if output.stopped() {
        return Err(Error::Conflict("cancelled after provider consumption"));
    }
    let response =
        ledger.dispatch_provider(&permit, || transport.open(permit.plan(), permit.route()))??;
    let mut reader = sse::Decoder::new(response, &plan.model);
    let mut batch = Vec::with_capacity(batch_rows);
    loop {
        if output.stopped() {
            return Err(Error::Conflict("provider response cancelled"));
        }
        let event = reader.next()?;
        let terminal = event.kind == weaver_contracts::ProviderEventKind::Done;
        batch.push(event);
        if terminal || batch.len() == batch_rows {
            // Flow-control capacity is reserved outside the deciding write lock.
            let slot = output.reserve()?;
            let digest = weaver_contracts::body_digest(&serde_json::to_string(&batch)?);
            let release =
                ledger.prepare_provider_release(&permit, &digest, format, batch.len() as u64)?;
            if output.stopped() {
                return Err(Error::Conflict("provider release cancelled"));
            }
            ledger.release_provider(&permit, release, format, |first| {
                if output.stopped() {
                    return Err(Error::Conflict("provider release cancelled"));
                }
                for (offset, event) in batch.iter_mut().enumerate() {
                    event.sequence = first + offset as u64;
                }
                output.emit(slot, permit.route(), &plan.model, &batch)
            })?;
            batch.clear();
        }
        if terminal {
            break;
        }
    }
    ledger.complete_provider(&permit, format)
}
