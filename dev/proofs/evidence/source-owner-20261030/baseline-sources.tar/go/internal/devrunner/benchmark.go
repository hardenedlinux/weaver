package devrunner

import (
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"time"
)

// Copy only structured Criterion data; raw stage logs retain Go/Rust environment receipts.
func collectBenchmarks(root, directory, started string) error {
	begin, err := time.Parse(time.RFC3339Nano, started)
	if err != nil {
		return err
	}
	source := filepath.Join(root, "target/criterion")
	groups := map[string]bool{}
	rows := []string{}
	err = filepath.WalkDir(source, func(path string, entry fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if entry.IsDir() {
			return nil
		}
		if filepath.Ext(path) != ".json" && filepath.Ext(path) != ".csv" {
			return nil
		}
		info, err := entry.Info()
		if err != nil {
			return err
		}
		if info.ModTime().Before(begin) {
			return nil
		}
		relative, err := filepath.Rel(source, path)
		if err != nil {
			return err
		}
		bytes, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		target := filepath.Join(directory, "criterion", relative)
		if err := os.MkdirAll(filepath.Dir(target), 0700); err != nil {
			return err
		}
		if err := os.WriteFile(target, bytes, 0600); err != nil {
			return err
		}
		if strings.HasSuffix(filepath.ToSlash(relative), "/new/estimates.json") {
			// Criterion names confidence bounds explicitly.
			var value map[string]json.RawMessage
			if err := json.Unmarshal(bytes, &value); err != nil {
				return err
			}
			var mean struct {
				Point    float64 `json:"point_estimate"`
				Interval struct {
					Lower float64 `json:"lower_bound"`
					Upper float64 `json:"upper_bound"`
				} `json:"confidence_interval"`
			}
			if err := json.Unmarshal(value["mean"], &mean); err != nil {
				return err
			}
			name := strings.TrimSuffix(filepath.ToSlash(relative), "/new/estimates.json")
			for _, group := range []string{"contracts", "policy", "ledger", "execution", "server"} {
				if strings.HasPrefix(name, group) {
					groups[group] = true
				}
			}
			rows = append(rows, fmt.Sprintf("| %s | %.3f | %.3f | %.3f |", name, mean.Point, mean.Interval.Lower, mean.Interval.Upper))
		}
		return nil
	})
	if err != nil {
		return err
	}
	if len(groups) != 5 {
		return errors.New("Criterion data does not cover all five Rust packages")
	}
	slices.Sort(rows)
	report := "#+TITLE: Native Rust Benchmark Baseline\n#+LANGUAGE: en\n\n* Scope\nLocal empirical baseline, not a throughput guarantee. Values are nanoseconds per measured iteration. CPU, compiler and client environment are in the adjacent stage logs. Go RPC client allocations are not Rust allocations.\n\n| Benchmark | Mean ns | Lower confidence bound ns | Upper confidence bound ns |\n|-----------+---------+---------------------------+---------------------------|\n" + strings.Join(rows, "\n") + "\n"
	return os.WriteFile(filepath.Join(directory, "benchmark-summary.org"), []byte(report), 0600)
}
