namespace Weaver.PublicationRecovery

/- Native refinement premises: authenticated stable source scope; exact domain-
   separated request commitment; durable non-rollback SQLite transaction jointly
   writes authority/schema and immutable decision; retained records are not pruned.
   head counts committed versions (zero is absent), not the wire revision ordinal.
   Schema validation, storage durability and authenticated transport are native
   obligations; this proof does not establish anti-rollback anchors. -/
structure Decision where
  payload : Nat
  parent : Nat
  requestedFence : Nat
  committed : Bool
  resultHead : Nat
  resultFence : Nat
  deriving DecidableEq

structure State (Key : Type) where
  head : Nat := 0
  fence : Nat := 1
  records : Key → Option Decision := fun _ => none
  commits : List Key := []
  held : Nat := 4
  calls : Nat := 1

variable {Key : Type}

def write [DecidableEq Key] (records : Key → Option Decision) (id : Key) (d : Decision) :=
  fun key => if key = id then some d else records key

def Extends (s t : State Key) : Prop := ∀ id d, s.records id = some d → t.records id = some d
def Safe (held calls : Nat) (s : State Key) : Prop := s.head = s.commits.length ∧ s.held = held ∧ s.calls = calls

inductive Step [DecidableEq Key] : State Key → State Key → Prop where
  | commit (s : State Key) (id : Key) (payload fence : Nat) (fresh : s.records id = none) (monotone : s.fence ≤ fence) :
      Step s {s with head := s.head+1, fence := fence, commits := s.commits ++ [id], records := write s.records id ⟨payload,s.head,fence,true,s.head+1,fence⟩}
  | reject (s : State Key) (id : Key) (payload parent fence : Nat) (fresh : s.records id = none)
      (conflict : parent ≠ s.head ∨ fence < s.fence) :
      Step s {s with records := write s.records id ⟨payload,parent,fence,false,s.head,s.fence⟩}
  | replayOrObservationOrRestart (s) : Step s s

variable {s t : State Key}
variable {held calls : Nat}

theorem step_preserves_original_decisions [DecidableEq Key] (step : Step s t) : Extends s t := by
  intro key d existing
  cases step with
  | commit id payload fence fresh monotone =>
    by_cases same : key = id
    · subst key; rw [fresh] at existing; contradiction
    · simpa [write, same] using existing
  | reject id payload parent fence fresh conflict =>
    by_cases same : key = id
    · subst key; rw [fresh] at existing; contradiction
    · simpa [write, same] using existing
  | replayOrObservationOrRestart => exact existing

theorem step_preserves_accounting [DecidableEq Key] (h : Safe held calls s) (step : Step s t) : Safe held calls t := by
  cases step <;> simp_all [Safe]

inductive Run [DecidableEq Key] : State Key → State Key → Prop where
  | refl (s : State Key) : Run s s
  | next {a b c : State Key} : Run a b → Step b c → Run a c

theorem run_preserves_original_decisions [DecidableEq Key] (run : Run s t) : Extends s t := by
  induction run with
  | refl => intro id d existing; exact existing
  | next history step ih =>
    intro id d existing
    exact step_preserves_original_decisions step id d (ih id d existing)

theorem run_preserves_accounting [DecidableEq Key] (h : Safe held calls s) (run : Run s t) : Safe held calls t := by
  induction run with
  | refl => exact h
  | next history step ih => exact step_preserves_accounting ih step

theorem recovery_and_provider_accounting_composition [DecidableEq Key]
    {id : Key} {decision : Decision}
    (h : Safe held calls s) (run : Run s t) (original : s.records id = some decision) :
    t.records id = some decision ∧ t.held = held ∧ t.calls = calls :=
  ⟨run_preserves_original_decisions run id decision original,
   (run_preserves_accounting h run).2.1, (run_preserves_accounting h run).2.2⟩

#print axioms step_preserves_original_decisions
#print axioms step_preserves_accounting
#print axioms run_preserves_original_decisions
#print axioms run_preserves_accounting
#print axioms recovery_and_provider_accounting_composition
end Weaver.PublicationRecovery
